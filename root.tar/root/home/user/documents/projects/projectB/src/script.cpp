#include <iostream>
using namespace std;
int main() {
    int a;
    cin >> a;
    if (a % 2 == 0)  // if remainder is zero then even number
        cout << �even�;
    else
        cout << �odd�;
    return 0;
}